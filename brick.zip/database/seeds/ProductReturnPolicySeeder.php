<?php

use Illuminate\Database\Seeder;

class ProductReturnPolicySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
