<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ProductReturnPolicy;
use Faker\Generator as Faker;

$factory->define(ProductReturnPolicy::class, function (Faker $faker) {
    return [
        //
    ];
});
