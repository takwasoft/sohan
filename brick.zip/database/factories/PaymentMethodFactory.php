<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\PaymentMethod;
use Faker\Generator as Faker;

$factory->define(PaymentMethod::class, function (Faker $faker) {
    return [
        //
    ];
});
