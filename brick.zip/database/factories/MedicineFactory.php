<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Medicine;
use Faker\Generator as Faker;

$factory->define(Medicine::class, function (Faker $faker) {
    return [
        //
    ];
});
