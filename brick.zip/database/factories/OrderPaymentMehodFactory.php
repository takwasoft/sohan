<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\OrderPaymentMehod;
use Faker\Generator as Faker;

$factory->define(OrderPaymentMehod::class, function (Faker $faker) {
    return [
        //
    ];
});
