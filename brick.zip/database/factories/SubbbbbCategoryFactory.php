<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SubbbbbCategory;
use Faker\Generator as Faker;

$factory->define(SubbbbbCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
