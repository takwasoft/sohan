<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Color;
use Faker\Generator as Faker;

$factory->define(Color::class, function (Faker $faker) {
    return [
        //
    ];
});
