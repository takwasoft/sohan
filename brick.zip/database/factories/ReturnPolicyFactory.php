<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ReturnPolicy;
use Faker\Generator as Faker;

$factory->define(ReturnPolicy::class, function (Faker $faker) {
    return [
        //
    ];
});
