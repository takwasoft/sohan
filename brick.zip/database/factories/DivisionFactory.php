<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Division;
use Faker\Generator as Faker;

$factory->define(Division::class, function (Faker $faker) {
    return [
        //
    ];
});
