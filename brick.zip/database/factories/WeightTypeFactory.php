<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\WeightType;
use Faker\Generator as Faker;

$factory->define(WeightType::class, function (Faker $faker) {
    return [
        //
    ];
});
