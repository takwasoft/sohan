<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SupplierReview;
use Faker\Generator as Faker;

$factory->define(SupplierReview::class, function (Faker $faker) {
    return [
        //
    ];
});
