<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Buyer;
use Faker\Generator as Faker;

$factory->define(Buyer::class, function (Faker $faker) {
    return [
        //
    ];
});
