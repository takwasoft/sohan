<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ColorProduct;
use Faker\Generator as Faker;

$factory->define(ColorProduct::class, function (Faker $faker) {
    return [
        //
    ];
});
