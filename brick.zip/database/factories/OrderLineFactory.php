<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\OrderLine;
use Faker\Generator as Faker;

$factory->define(OrderLine::class, function (Faker $faker) {
    return [
        //
    ];
});
