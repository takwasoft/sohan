<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Boost;
use Faker\Generator as Faker;

$factory->define(Boost::class, function (Faker $faker) {
    return [
        //
    ];
});
