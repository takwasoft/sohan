<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ParentCategory;
use Faker\Generator as Faker;

$factory->define(ParentCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
