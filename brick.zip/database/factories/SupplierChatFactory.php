<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SupplierChat;
use Faker\Generator as Faker;

$factory->define(SupplierChat::class, function (Faker $faker) {
    return [
        //
    ];
});
