<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\undefined;
use Faker\Generator as Faker;

$factory->define(undefined::class, function (Faker $faker) {
    return [
        //
    ];
});
