<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SupplierCategory;
use Faker\Generator as Faker;

$factory->define(SupplierCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
