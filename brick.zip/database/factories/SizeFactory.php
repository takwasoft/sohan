<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Size;
use Faker\Generator as Faker;

$factory->define(Size::class, function (Faker $faker) {
    return [
        //
    ];
});
