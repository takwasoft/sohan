<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ProductReview;
use Faker\Generator as Faker;

$factory->define(ProductReview::class, function (Faker $faker) {
    return [
        //
    ];
});
