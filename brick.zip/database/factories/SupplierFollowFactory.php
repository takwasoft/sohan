<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SupplierFollow;
use Faker\Generator as Faker;

$factory->define(SupplierFollow::class, function (Faker $faker) {
    return [
        //
    ];
});
