<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ProductPaymentMethod;
use Faker\Generator as Faker;

$factory->define(ProductPaymentMethod::class, function (Faker $faker) {
    return [
        //
    ];
});
