<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\SubDistrict;
use Faker\Generator as Faker;

$factory->define(SubDistrict::class, function (Faker $faker) {
    return [
        //
    ];
});
