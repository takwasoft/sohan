<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\ProductImage;
use Faker\Generator as Faker;

$factory->define(ProductImage::class, function (Faker $faker) {
    return [
        //
    ];
});
