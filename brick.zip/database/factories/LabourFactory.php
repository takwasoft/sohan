<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Labour;
use Faker\Generator as Faker;

$factory->define(Labour::class, function (Faker $faker) {
    return [
        //
    ];
});
