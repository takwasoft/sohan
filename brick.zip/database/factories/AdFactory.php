<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\Ad;
use Faker\Generator as Faker;

$factory->define(Ad::class, function (Faker $faker) {
    return [
        //
    ];
});
