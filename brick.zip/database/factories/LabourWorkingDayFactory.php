<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\model\LabourWorkingDay;
use Faker\Generator as Faker;

$factory->define(LabourWorkingDay::class, function (Faker $faker) {
    return [
        //
    ];
});
