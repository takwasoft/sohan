<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class SupplierFollow extends Model
{
    
protected $fillable = [
'id','buyer_id','supplier_id'
];
                    
}
