<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model
{
    
protected $fillable = [
'id','name','value'
];
                    
}
