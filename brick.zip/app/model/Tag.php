<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    
protected $fillable = [
'id','name'
];
                    
}
