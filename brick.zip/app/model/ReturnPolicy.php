<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class ReturnPolicy extends Model
{
    
protected $fillable = [
'id','title','day','custom'
];
                    
} 
