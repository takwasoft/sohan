<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class SupplierCategory extends Model
{
    
protected $fillable = [
'id','name','details'
];
                    
}
