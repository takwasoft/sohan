<?php

namespace App\Http\Resources\SupplierChat;

use Illuminate\Http\Resources\Json\JsonResource;

class SupplierChatResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
           // 'id' => $this->id,
           // 'name' => $this->name
        ];
    }
}
